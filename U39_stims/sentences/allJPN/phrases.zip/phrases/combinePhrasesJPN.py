from pydub import AudioSegment
from pydub.silence import split_on_silence
from collections import OrderedDict
import itertools

#sound = AudioSegment.from_wav("phrases.wav")
#print sound.dBFS
# chunks = split_on_silence(sound, 
#     # must be silent for at least a second
#     min_silence_len=1000,

#     # consider it silent if quieter than -16 dBFS
#     silence_thresh=-58.5
# )

# print chunks
# for i, chunk in enumerate(chunks):
#     chunk.export("chunk{0}.wav".format(i), format="wav")


def split_byGroup(meaning_list):
  nouns = [meaning  for meaning in meaning_list if len(meaning.split('_')) == 1 and meaning[-2:]!='ra']
  verbs = [meaning  for meaning in meaning_list if len(meaning.split('_')) == 1 and meaning[-2:]=='ra']
  one_marker = [meaning  for meaning in meaning_list if len(meaning.split('_')) == 2]
  two_marker = [meaning for meaning in meaning_list if len(meaning.split('_')) == 3]
  return OrderedDict(zip(['verb','noun','oneMarker','twoMarker',] , [verbs,nouns,one_marker, two_marker]))


list_writtenPhrases= ['sogina_sehi_gito', 'dakume_sehi_gito', 'nechibi_sehi_gito', 'tasonu_sehi_gito', 'sogina_sehi_yoza', 'dakume_sehi_yoza', 'nechibi_sehi_yoza', 'tasonu_sehi_yoza', 'sogina_gito_sehi', 'dakume_gito_sehi', 'nechibi_gito_sehi', 'tasonu_gito_sehi', 'sogina_gito_yoza', 'dakume_gito_yoza', 'nechibi_gito_yoza', 'tasonu_gito_yoza', 'sogina_yoza_sehi', 'dakume_yoza_sehi', 'nechibi_yoza_sehi', 'tasonu_yoza_sehi', 'sogina_yoza_gito', 'dakume_yoza_gito', 'nechibi_yoza_gito', 'tasonu_yoza_gito', 'sehi_gito_sogina', 'sehi_gito_dakume', 'sehi_gito_nechibi', 'sehi_gito_tasonu', 'sehi_yoza_sogina', 'sehi_yoza_dakume', 'sehi_yoza_nechibi', 'sehi_yoza_tasonu', 'gito_sehi_sogina', 'gito_sehi_dakume', 'gito_sehi_nechibi', 'gito_sehi_tasonu', 'gito_yoza_sogina', 'gito_yoza_dakume', 'gito_yoza_nechibi', 'gito_yoza_tasonu', 'yoza_sehi_sogina', 'yoza_sehi_dakume', 'yoza_sehi_nechibi', 'yoza_sehi_tasonu', 'yoza_gito_sogina', 'yoza_gito_dakume', 'yoza_gito_nechibi', 'yoza_gito_tasonu', 'sogina_sehi', 'dakume_sehi', 'nechibi_sehi', 'tasonu_sehi', 'sogina_gito', 'dakume_gito', 'nechibi_gito', 'tasonu_gito', 'sogina_yoza', 'dakume_yoza', 'nechibi_yoza', 'tasonu_yoza', 'sehi_sogina', 'sehi_dakume', 'sehi_nechibi', 'sehi_tasonu', 'gito_sogina', 'gito_dakume', 'gito_nechibi', 'gito_tasonu', 'yoza_sogina', 'yoza_dakume', 'yoza_nechibi', 'yoza_tasonu', 'sogina', 'dakume', 'nechibi', 'tasonu', 'kerura', 'nagura', 'sasura']
list_audioFiles = []
path=''
for phrase in list_writtenPhrases:
	file=phrase+'.wav'
	list_audioFiles.append(AudioSegment.from_wav(file))

d_audioPhrases = OrderedDict(zip(list_writtenPhrases,list_audioFiles))
d_phrasesByGroup = split_byGroup(list_writtenPhrases)


combi_phrases=[i for i in itertools.permutations(d_phrasesByGroup['oneMarker'],2)]
sentences = []
sentences_text =[]
for verb in d_phrasesByGroup['verb']:
	for noun in d_phrasesByGroup['noun']:
		for phrase in d_phrasesByGroup['oneMarker']:
			string=verb+'_'+noun+'_'+phrase
			if len(set(string.split('_'))) == len(string.split('_')):
				sentences.append(d_audioPhrases[verb]+d_audioPhrases[noun]+d_audioPhrases[phrase])
				sentences_text.append(string)
		for phrase in combi_phrases:
			string = verb+'_'+phrase[0]+'_'+phrase[1]
			middle_words = [string.split('_')[2],string.split('_')[3]]
			peri_words = [string.split('_')[1],string.split('_')[4]]
			if len(set(string.split('_'))) == len(string.split('_')) and all(word in ['tehi','gito', 'yoza'] for word in middle_words)==False and all(word in ['tehi','gito', 'yoza'] for word in peri_words)==False:
				sentences.append(d_audioPhrases[verb]+d_audioPhrases[phrase[0]]+d_audioPhrases[phrase[1]])
				sentences_text.append(string)		
		for complex_phrase in d_phrasesByGroup['twoMarker']:
			string = verb+'_'+noun+'_'+complex_phrase
			if len(set(string.split('_'))) == len(string.split('_')):
				sentences.append(d_audioPhrases[verb]+d_audioPhrases[noun]+d_audioPhrases[complex_phrase])
		 		sentences_text.append(string)

d_sentences=OrderedDict(zip(sentences_text,sentences))

#print len(d_sentences) #=1080

# for sentence in d_sentences.keys():
# 	filename=sentence+".wav"
# 	new_file=d_sentences[sentence]
# 	new_file.export(filename, format="wav")





