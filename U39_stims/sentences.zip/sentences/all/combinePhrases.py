from pydub import AudioSegment
from pydub.silence import split_on_silence
from collections import OrderedDict
import itertools

#sound = AudioSegment.from_wav("phrases.wav")
#print sound.dBFS
# chunks = split_on_silence(sound, 
#     # must be silent for at least a second
#     min_silence_len=1000,

#     # consider it silent if quieter than -16 dBFS
#     silence_thresh=-58.5
# )

# print chunks
# for i, chunk in enumerate(chunks):
#     chunk.export("chunk{0}.wav".format(i), format="wav")


def split_byGroup(meaning_list):
  nouns = [meaning  for meaning in meaning_list if len(meaning.split('_')) == 1 and meaning[-2:]!='im']
  verbs = [meaning  for meaning in meaning_list if len(meaning.split('_')) == 1 and meaning[-2:]=='im']
  one_marker = [meaning  for meaning in meaning_list if len(meaning.split('_')) == 2]
  two_marker = [meaning for meaning in meaning_list if len(meaning.split('_')) == 3]
  return OrderedDict(zip(['verb','noun','oneMarker','twoMarker',] , [verbs,nouns,one_marker, two_marker]))


list_writtenPhrases = ['negid_gu_sa', 'tumbat_gu_sa', 'vaem_gu_sa', 'nork_gu_sa', 'negid_gu_ti', 'tumbat_gu_ti', 'vaem_gu_ti', 'nork_gu_ti', 'negid_sa_gu', 'tumbat_sa_gu', 'vaem_sa_gu', 'nork_sa_gu', 'negid_sa_ti', 'tumbat_sa_ti', 'vaem_sa_ti', 'nork_sa_ti', 'negid_ti_gu', 'tumbat_ti_gu', 'vaem_ti_gu', 'nork_ti_gu', 'negid_ti_sa', 'tumbat_ti_sa', 'vaem_ti_sa', 'nork_ti_sa', 'gu_sa_negid', 'gu_sa_tumbat', 'gu_sa_vaem', 'gu_sa_nork', 'gu_ti_negid', 'gu_ti_tumbat', 'gu_ti_vaem', 'gu_ti_nork', 'sa_gu_negid', 'sa_gu_tumbat', 'sa_gu_vaem', 'sa_gu_nork', 'sa_ti_negid', 'sa_ti_tumbat', 'sa_ti_vaem', 'sa_ti_nork', 'ti_gu_negid', 'ti_gu_tumbat', 'ti_gu_vaem', 'ti_gu_nork', 'ti_sa_negid', 'ti_sa_tumbat', 'ti_sa_vaem', 'ti_sa_nork', 'negid_gu', 'tumbat_gu', 'vaem_gu', 'nork_gu', 'negid_sa', 'tumbat_sa', 'vaem_sa', 'nork_sa', 'negid_ti', 'tumbat_ti', 'vaem_ti', 'nork_ti', 'gu_negid', 'gu_tumbat', 'gu_vaem', 'gu_nork', 'sa_negid', 'sa_tumbat', 'sa_vaem', 'sa_nork', 'ti_negid', 'ti_tumbat', 'ti_vaem', 'ti_nork', 'negid', 'tumbat', 'vaem', 'nork', 'kikim', 'straikim', 'poinim']
list_audioFiles = []
path=''
for phrase in list_writtenPhrases:
	file=phrase+'.wav'
	list_audioFiles.append(AudioSegment.from_wav(file))

d_audioPhrases = OrderedDict(zip(list_writtenPhrases,list_audioFiles))
d_phrasesByGroup = split_byGroup(list_writtenPhrases)


combi_phrases=[i for i in itertools.permutations(d_phrasesByGroup['oneMarker'],2)]
sentences = []
sentences_text =[]
for verb in d_phrasesByGroup['verb']:
	for noun in d_phrasesByGroup['noun']:
		for phrase in d_phrasesByGroup['oneMarker']:
			string=verb+'_'+noun+'_'+phrase
			if len(set(string.split('_'))) == len(string.split('_')):
				sentences.append(d_audioPhrases[verb]+d_audioPhrases[noun]+d_audioPhrases[phrase])
				sentences_text.append(string)
		for phrase in combi_phrases:
			string = verb+'_'+phrase[0]+'_'+phrase[1]
			middle_words = [string.split('_')[2],string.split('_')[3]]
			peri_words = [string.split('_')[1],string.split('_')[4]]
			if len(set(string.split('_'))) == len(string.split('_')) and all(word in ['gu','ti', 'sa'] for word in middle_words)==False and all(word in ['gu','ti', 'sa'] for word in peri_words)==False:
				sentences.append(d_audioPhrases[verb]+d_audioPhrases[phrase[0]]+d_audioPhrases[phrase[1]])
				sentences_text.append(string)		
		for complex_phrase in d_phrasesByGroup['twoMarker']:
			string = verb+'_'+noun+'_'+complex_phrase
			if len(set(string.split('_'))) == len(string.split('_')):
				sentences.append(d_audioPhrases[verb]+d_audioPhrases[noun]+d_audioPhrases[complex_phrase])
		 		sentences_text.append(string)

d_sentences=OrderedDict(zip(sentences_text,sentences))



# for sentence in d_sentences.keys():
# 	filename=sentence+".wav"
# 	new_file=d_sentences[sentence]
# 	new_file.export(filename, format="wav")





